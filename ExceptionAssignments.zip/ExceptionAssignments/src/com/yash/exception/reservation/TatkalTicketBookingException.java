package com.yash.exception.reservation;

public class TatkalTicketBookingException extends RuntimeException {

	public TatkalTicketBookingException(String s) {
		super(s);

	}

}
