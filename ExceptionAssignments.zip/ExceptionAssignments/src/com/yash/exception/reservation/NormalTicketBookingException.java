package com.yash.exception.reservation;

public class NormalTicketBookingException extends RuntimeException {

	public NormalTicketBookingException(String s) {
		super(s);

	}

}
