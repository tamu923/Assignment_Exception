package com.yash.exception.items;

public class ItemBought {
	
	long itemid;
	int itemqty;
	
	
	
}
