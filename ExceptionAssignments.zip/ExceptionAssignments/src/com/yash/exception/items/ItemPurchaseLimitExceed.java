package com.yash.exception.items;

public class ItemPurchaseLimitExceed extends RuntimeException {

	public ItemPurchaseLimitExceed(String s) {

		super(s);
	}

}
