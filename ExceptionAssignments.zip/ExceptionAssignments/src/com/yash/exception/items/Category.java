package com.yash.exception.items;

public class Category {

	
	long catid;
	String categoryname;
	
	
}
