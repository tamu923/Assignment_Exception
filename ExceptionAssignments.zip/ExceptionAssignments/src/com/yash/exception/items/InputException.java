package com.yash.exception.items;

public class InputException extends RuntimeException {

	public InputException(String s) {

		super(s);
	}

}
