package com.yash.exception.shirtsfactory;

public class CollarStandardDeviateException extends RuntimeException {

	public CollarStandardDeviateException(String s) {
		super(s);
	}

}
