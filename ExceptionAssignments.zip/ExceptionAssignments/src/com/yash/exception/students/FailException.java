package com.yash.exception.students;

public class FailException extends RuntimeException  {

	
	public FailException(String s) {
		super(s);

	}
}
