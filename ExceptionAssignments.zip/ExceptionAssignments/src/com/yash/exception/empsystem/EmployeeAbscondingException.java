package com.yash.exception.empsystem;

public class EmployeeAbscondingException extends RuntimeException  {

	public EmployeeAbscondingException(String s){
		
		super(s);
		
	}
	
}
