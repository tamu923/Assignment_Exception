package com.yash.exception.empsystem;

public class LeaveExceedLimitException extends RuntimeException{

	public LeaveExceedLimitException(String s) {
		super(s);
	}

}
